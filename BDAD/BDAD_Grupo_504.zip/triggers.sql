
/* Quando um projeto lei for aprovado, deve passar a decreto lei.*/

CREATE TRIGGER Aprova_Decreto
AFTER INSERT ON Projetos_Aprovados
FOR EACH ROW
BEGIN

INSERT INTO Decreto_Lei (codigo, descricao, id_projeto)
SELECT codigo, descricao, Projeto_Lei.id_projeto
FROM Projeto_Lei 
INNER JOIN Projetos_Aprovados ON (Projetos_Aprovados.id_projeto = Projeto_Lei.id_projeto)
WHERE Projeto_Lei.id_projeto = new.id_projeto; /*Inserir o novo decreto com os dados do projeto-lei correspondente.*/

UPDATE Decreto_Lei
SET data_aprovacao = DATE('now')
WHERE id_decreto = 
(SELECT id_decreto FROM Decreto_Lei
ORDER BY id_decreto DESC LIMIT 1); /*Inserir automaticamente a data de aprovação (pela data de inserção dos dados na BD)*/

END;

/*Quando um novo Governo é adicionado, a data da última eleição do Parlamento deve passar a ser a data de início do novo Governo.
  Também deve atualizar devidamente o registo do Governo anterior (dataFim). */

CREATE TRIGGER Novo_Governo
AFTER INSERT ON Governo
FOR EACH ROW
BEGIN

UPDATE Governo
SET dataFim = (SELECT dataInicio FROM Governo ORDER BY id_governo DESC LIMIT 1)
WHERE id_governo = (SELECT id_governo FROM Governo ORDER BY id_governo DESC LIMIT 1) - 1; /*Atualizar a dataFim do Governo anterior */

INSERT INTO Parlamento (localSede, tipo)
SELECT localSede, tipo
FROM Parlamento
WHERE id_parlamento = (SELECT id_parlamento FROM Parlamento ORDER BY id_parlamento DESC LIMIT 1); /*Inserir um novo registo de Parlamento, com o novo Governo*/

UPDATE Parlamento
SET id_governo = new.id_governo,
ultimaEleicao = (SELECT dataInicio FROM Governo ORDER BY id_governo DESC LIMIT 1)
WHERE id_parlamento = (SELECT id_parlamento FROM Parlamento ORDER BY id_parlamento DESC LIMIT 1); /*Atualizar a ultimaEleicao do Parlamento com a dataInicio do novo Governo*/

END;

/*Quando uma nova pessoa é adicionada a um Governo, testar se um certo número de membros é alcançado. 
Caso seja verdade, então testa se existe maioria absoluta. 
Caso a percentagem de membros de um certo partido seja superior ou igual a 50%, então o campo maioria passa a true (1).*/

CREATE TRIGGER Testa_Maioria
BEFORE INSERT ON Pessoa_Parlamento
FOR EACH ROW
WHEN (new.papel != "Deputado" AND new.papel != "Presidente da Republica" AND new.papel != "Vice-Presidente" AND new.papel != "Presidente da Assembleia")
BEGIN

/*Caso os dois SELECT's retornem resultados, significa que o campo maioria deverá ser atualizado.*/

UPDATE Governo SET maioria = 1
WHERE EXISTS(
/*Selecionar se o Governo possui maioria absoluta*/
SELECT percentagem_maxima FROM(
SELECT MAX(percentagem) AS percentagem_maxima FROM(
SELECT partido, (COUNT(*)/(num*1.0))*100 AS percentagem FROM(
SELECT Pessoa.nome, Partido.nome AS partido, Pessoa_Parlamento.papel AS PapelPessoa FROM Pessoa
INNER JOIN Pessoa_Parlamento ON (Pessoa_Parlamento.id_pessoa = Pessoa.id_pessoa)
INNER JOIN Parlamento ON (Parlamento.id_parlamento = Pessoa_Parlamento.id_parlamento)
INNER JOIN Pessoa_Partido ON (Pessoa_Partido.id_pessoa = Pessoa.id_pessoa)
INNER JOIN Partido ON (Pessoa_Partido.id_partido = Partido.id_partido)
WHERE Parlamento.id_parlamento IN
(SELECT id_parlamento FROM Ultimo_Parlamento)
AND PapelPessoa NOT IN("Deputado", "Presidente da Republica", "Vice-Presidente", "Presidente da Assembleia"))Partidos_Num_Membros_Parlamento, Num_Pessoas_Parlamento
GROUP BY partido))
WHERE percentagem_maxima >= 50 

AND EXISTS
/*Selecionar o número de membros, caso a inserção da nova pessoa faça com que esse número alcance o máximo de membros.*/
(SELECT num_membros FROM
(SELECT Governo.id_governo, COUNT(*) AS num_membros, maximo_membros
FROM Pessoa
INNER JOIN Pessoa_Parlamento ON (Pessoa_Parlamento.id_pessoa = Pessoa.id_pessoa)
INNER JOIN Parlamento ON (Parlamento.id_parlamento = Pessoa_Parlamento.id_parlamento)
INNER JOIN Governo ON (Governo.id_governo = Parlamento.id_governo)
WHERE Governo.id_governo = 
(SELECT Governo.id_governo FROM Pessoa
INNER JOIN Pessoa_Parlamento ON (Pessoa_Parlamento.id_pessoa = Pessoa.id_pessoa)
INNER JOIN Parlamento ON (Parlamento.id_parlamento = Pessoa_Parlamento.id_parlamento)
INNER JOIN Governo ON (Governo.id_governo = Parlamento.id_governo)
WHERE Parlamento.id_parlamento = new.id_parlamento)
GROUP BY Governo.id_governo) Num_Membros_Governo_Atual
WHERE num_membros >= maximo_membros - 1) 
AND id_governo = (SELECT id_parlamento FROM Ultimo_Parlamento));

/*Caso o Governo já estiver completo e a pessoa a introduzir quiser fazer parte do Governo (papel), então faz ABORT e mostra a mensagem abaixo. */

SELECT RAISE(ABORT, "O Governo ja contem todos os membros")
WHERE EXISTS(
SELECT num_membros FROM
(SELECT Governo.id_governo, COUNT(*) AS num_membros, maximo_membros
FROM Pessoa
INNER JOIN Pessoa_Parlamento ON (Pessoa_Parlamento.id_pessoa = Pessoa.id_pessoa)
INNER JOIN Parlamento ON (Parlamento.id_parlamento = Pessoa_Parlamento.id_parlamento)
INNER JOIN Governo ON (Governo.id_governo = Parlamento.id_governo)
WHERE Governo.id_governo = 
(SELECT Governo.id_governo FROM Pessoa
INNER JOIN Pessoa_Parlamento ON (Pessoa_Parlamento.id_pessoa = Pessoa.id_pessoa)
INNER JOIN Parlamento ON (Parlamento.id_parlamento = Pessoa_Parlamento.id_parlamento)
INNER JOIN Governo ON (Governo.id_governo = Parlamento.id_governo)
WHERE Parlamento.id_parlamento = new.id_parlamento)
AND Pessoa_Parlamento.papel NOT IN("Deputado", "Presidente da Republica", "Vice-Presidente", "Presidente da Assembleia") 
GROUP BY Governo.id_governo) Num_Membros_Governo_Atual
WHERE num_membros >= maximo_membros);
 
END;
