INSERT INTO Parlamento VALUES (NULL, 'Palacio de S.Bento',  '2011-06-05',  'Unicameral', 1),
							  (NULL, 'Palácio de S.Bento', '2014-04-05', 'Unicameral', 2);

INSERT INTO Governo VALUES (NULL, '2011-06-05', '', 1, 3),
						   (NULL, '2014-05-05', '', 0, 3);

INSERT INTO Grupo_Parlamentar VALUES (NULL, 'PS'), 
									 (NULL, 'PSD'), 
									 (NULL, 'CDS'), 
									 (NULL, 'PCP');

INSERT INTO Mesa VALUES (NULL, 'A mesa e composta por unicamente 13 pessoas.', '2011-06-05', '2014-12-12');

INSERT INTO Espetro VALUES (NULL, 'Esquerda'), 
						   (NULL, 'Direita'),
						   (NULL, 'Centro-Esquerda'), 
						   (NULL, 'Centro-Direita');
									
INSERT INTO Ministerio VALUES (NULL, 'Ministerio das Financas', 1), 
							  (NULL, 'Ministerio da Economia', 1),
							  (NULL, 'Ministerio da Educacao', 1), 
							  (NULL, 'Ministerio da Saude', 1),
							  (NULL, 'Ministerio da Defesa', 1), 
							  (NULL, 'Ministerio dos Negocios Estrangeiros', 1),
							  (NULL, 'Ministerio da Justica', 1),
							  (NULL, 'Ministerio das Financas', 2);
							  
INSERT INTO Partido VALUES (NULL, 'Partido Socialista', 3), 
						   (NULL, 'Partido Social Democrata', 4),
						   (NULL, 'CDS-Partido Popular', 2), 
						   (NULL, 'Partido Comunista', 1);
								 
INSERT INTO Pessoa VALUES (NULL, 'Pedro Passos Coelho', '1964-07-24'),
						  (NULL, 'Vitor Gaspar', '1960-11-09'),
						  (NULL, 'Nuno Crato', '1952-03-09'),
						  (NULL, 'Cavaco Silva', '1939-07-15'),
						  (NULL, 'Mota Amaral', '1943-04-15'),
						  (NULL, 'Assuncao Esteves', '1956-10-15'),
						  (NULL, 'Paulo Portas', '1962-09-12'),
						  (NULL, 'Jeronimo de Sousa', '1947-04-13'),
						  (NULL, 'Ferro Rodrigues', '1949-11-03'),
						  (NULL, 'Paula Teixeira da Cruz', '1960-06-01'),
						  (NULL, 'Jose Ferreira Gomes', '1947-07-14'),
						  (NULL, 'Guilherme Silva', '1943-07-16'),
						  (NULL, 'Teresa Caeiro', '1969-02-14'),
						  (NULL, 'Antonio Filipe', '1963-01-28'),
						  (NULL, 'Duarte Pacheco', '1965-11-25'),
						  (NULL, 'Rosa Maria Bastos Albernaz', '1947-09-04'),
						  (NULL, 'Abel Baptista', '1963-10-13'),
						  (NULL, 'Jorge Machado', '1976-05-20'),
						  (NULL, 'Maria Paula Cardoso', '1962-08-24'),
						  (NULL, 'Pedro Alves', '1972-12-30'),
						  (NULL, 'Jorge Fao', '1957-11-04'),
						  (NULL, 'Raul de Almeida', '1968-05-08'),
						  (NULL, 'Antonio Jose Seguro', '1962-03-11'),
						  (NULL, 'Pedro Miguel', '2014-05-05'),
						  (NULL, 'Joao Ferreira', '1959-06-04');
						  
INSERT INTO Projeto_Lei VALUES (NULL, 'O seguinte projeto e apenas um teste...', 435),
							   (NULL, 'Este projeto lei ainda e um teste...', 562),
							   (NULL, 'Terceiro projeto lei...', 568),
							   (NULL, 'Quarto projeto lei...', 666),
							   (NULL, 'Quinto projeto...para trigger', 619);

INSERT INTO Decreto_Lei VALUES (NULL, 435, '2014-03-03', 'O seguinte projeto e apenas um teste...', 1),
							   (NULL, 562, '2014-03-05', 'Este projeto lei ainda e um teste...', 2),
							   (NULL, 568, '2013-06-06', 'Terceiro projeto lei...', 3),
							   (NULL, 666, '2014-03-06', 'Quarto projeto lei...', 4);
							   
INSERT INTO Projetos_Aprovados VALUES (1, 1, NULL),
									  (2, 1, NULL),
									  (3, NULL, 2),
									  (4, NULL, 1);
							   
INSERT INTO Altera_Decreto VALUES (1, 1, '2014-03-07'),
								  (3, 1, '2014-03-21');
					
INSERT INTO Pessoa_Grupo VALUES (5, 1, 'Deputado', '2014-04-10'),
								(8, 4, 'Lider', '2011-06-05'),
								(12, 1, 'Deputado', '2011-06-05'),
								(13, 3, 'Deputada', '2011-06-05'),
								(14, 4, 'Deputado', '2011-06-05'),
								(15, 1, 'Deputado', '2011-06-05'),
								(16, 2, 'Deputada', '2011-06-05'),
								(17, 3, 'Deputada', '2011-06-05'),
								(18, 4, 'Deputado', '2011-06-05'),
								(19, 1, 'Deputada', '2011-06-05'),
								(20, 1, 'Deputado', '2011-06-05'),
								(21, 2, 'Deputado', '2011-06-05'),
								(22, 3, 'Deputado', '2011-06-05'),
								(23, 2, 'Lider', '2011-06-05');
					
INSERT INTO Pessoa_Mesa VALUES (6, 1, 'Presidente da Assembleia', '2014-04-10'),
							   (9, 1, 'Vice-Presidente', '2011-06-05'),
							   (12, 1, 'Vice-Presidente', '2011-06-05'),
							   (13, 1, 'Vice-Presidente', '2011-06-05'),
							   (14, 1, 'Vice-Presidente', '2011-06-05'),
							   (15, 1, 'Secretario', '2011-06-05'),
							   (16, 1, 'Secretaria', '2011-06-05'),
							   (17, 1, 'Secretario', '2011-06-05'),
							   (18, 1, 'Secretario', '2011-06-05'),
							   (19, 1, 'Vice-Secretaria', '2011-06-05'),
							   (20, 1, 'Vice-Secretario', '2011-06-05'),
							   (21, 1, 'Vice-Secretario', '2011-06-05'),
							   (22, 1, 'Vice-Secretario', '2011-06-05');
								  
INSERT INTO Pessoa_Ministerio VALUES (2, 3, 'Ministro', '2014-04-10'),
									 (3, 4, 'Ministro', '2014-04-10'),
									 (10, 3, 'Ministra', '2011-06-05'),
									 (11, 3, 'Secretario de Estado', '2011-06-05'),
									 (24, 8, 'Deputado', '2014-04-03');

INSERT INTO Pessoa_Partido VALUES (1, 2, 'Secretario-Geral', '2014-04-10'),
								  (4, 2, 'Membro', '2014-04-10'),
								  (5, 2, 'Membro', '2014-04-10'),
								  (6, 1, 'Membro', '2014-04-10'),
								  (7, 3, 'Secretário-Geral', '2013-11-06'),
								  (8, 4, 'Secretário-Geral', '2013-08-13'),
								  (9, 1, 'Membro', '2013-09-17'),
								  (12, 2, 'Membro', '2013-11-12'),
								  (13, 3, 'Membro', '2013-10-17'),
								  (14, 4, 'Membro', '2013-11-13'),
								  (15, 2, 'Membro', '2013-12-20'),
								  (16, 1, 'Membro', '2012-12-15'),
								  (17, 3, 'Membro', '2013-09-20'),
								  (18, 4, 'Membro', '2013-11-14'),
								  (19, 2, 'Membro', '2013-08-06'),
								  (20, 2, 'Membro', '2013-08-06'),
								  (21, 1, 'Membro', '2013-10-09'),
								  (22, 3, 'Membro', '2013-11-05'),
								  (23, 1, 'Secretario-Geral', '2013-07-17'),
								  (24, 3, 'Secretario', '2013-06-10'),
								  (25, 1, 'Secretario', '2013-06-04');
									 
INSERT INTO Pessoa_Parlamento VALUES (1, 1, 'Primeiro-Ministro', '2014-04-08'),
									 (2, 1, 'Ministro', '2014-04-10'),
									 (3, 1, 'Ministro', '2014-04-10'),
									 (4, 1, 'Presidente da Republica', '2014-04-10'),
									 (5, 1, 'Deputado', '2014-04-10'),
									 (6, 1, 'Presidente da Assembleia', '2011-06-05'),
									 (7, 1, 'Vice-Primeiro-Ministro', '2011-06-05'),
									 (8, 1, 'Deputado', '2011-06-05'),
									 (9, 1, 'Deputado', '2011-06-05'),
									 (10, 1, 'Ministra', '2011-06-05'),
									 (11, 1, 'Secretario de Estado', '2011-06-05'),
									 (12, 1, 'Vice-Presidente', '2011-06-05'),
									 (13, 1, 'Vice-Presidente', '2011-06-05'),
									 (14, 1, 'Vice-Presidente', '2011-06-05'),
									 (15, 1, 'Secretario', '2011-06-05'),
									 (16, 1, 'Secretaria', '2011-06-05'),
									 (17, 1, 'Secretario', '2011-06-05'),
									 (18, 1, 'Secretario', '2011-06-05'),
									 (19, 1, 'Vice-Secretaria', '2011-06-05'),
									 (20, 1, 'Vice-Secretario', '2011-06-05'),
									 (21, 1, 'Vice-Secretario', '2011-06-05'),
									 (22, 1, 'Vice-Secretario', '2011-06-05'),
									 (23, 1, 'Deputado', '2011-06-05'),
									 (24, 1, 'Deputado', '2014-05-13'),
									 (24, 2, 'Deputado', '2014-05-04'),
									 (25, 2, 'Deputado', '2013-06-02');
									
/*
Views necesárias para alguns SELECT's.
*/
									
CREATE VIEW IF NOT EXISTS num_decretos_governo AS
SELECT id_governo, COUNT(*) AS Contagem
FROM Projetos_Aprovados
GROUP BY id_governo
HAVING id_governo IS NOT NULL;

CREATE VIEW IF NOT EXISTS num_decretos_alterados AS
SELECT id_governo, COUNT(*) AS contagem
FROM altera_decreto
GROUP BY id_governo;

CREATE VIEW IF NOT EXISTS Ultimo_Parlamento AS
SELECT id_parlamento
FROM Parlamento
ORDER BY id_parlamento DESC
LIMIT 1;

CREATE VIEW IF NOT EXISTS Num_Pessoas_Parlamento AS
SELECT COUNT(*) AS num
FROM Pessoa
INNER JOIN Pessoa_Parlamento ON (Pessoa_Parlamento.id_pessoa = Pessoa.id_pessoa)
INNER JOIN Parlamento ON (Parlamento.id_parlamento = Pessoa_Parlamento.id_parlamento)
WHERE Parlamento.id_parlamento IN(SELECT id_parlamento FROM Ultimo_Parlamento);

CREATE VIEW IF NOT EXISTS num_membros_ministerios AS
SELECT Governo.id_governo, Ministerio.id_ministerio, COUNT(*) AS num_membros
FROM Pessoa
INNER JOIN Pessoa_Parlamento ON (Pessoa.id_pessoa = Pessoa_Parlamento.id_pessoa)
INNER JOIN Parlamento ON (Parlamento.id_parlamento = Pessoa_Parlamento.id_parlamento)
INNER JOIN Governo ON (Governo.id_governo = Parlamento.id_governo)
INNER JOIN Ministerio ON (Ministerio.id_governo = Governo.id_governo)
INNER JOIN Pessoa_Ministerio ON (Pessoa.id_pessoa = Pessoa_Ministerio.id_pessoa)
WHERE Pessoa_Ministerio.id_ministerio = Ministerio.id_ministerio
GROUP BY Governo.id_governo, Ministerio.id_ministerio;