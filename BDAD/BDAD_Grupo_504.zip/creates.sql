DROP TABLE IF EXISTS Altera_Decreto;
DROP TABLE IF EXISTS Decreto_Lei;
DROP TABLE IF EXISTS Espetro;
DROP TABLE IF EXISTS Governo;
DROP TABLE IF EXISTS Grupo_Parlamentar;
DROP TABLE IF EXISTS Mesa;
DROP TABLE IF EXISTS Ministerio;
DROP TABLE IF EXISTS Parlamento;
DROP TABLE IF EXISTS Partido;
DROP TABLE IF EXISTS Pessoa;
DROP TABLE IF EXISTS Pessoa_Grupo;
DROP TABLE IF EXISTS Pessoa_Mesa;
DROP TABLE IF EXISTS Pessoa_Ministerio;
DROP TABLE IF EXISTS Pessoa_Parlamento;
DROP TABLE IF EXISTS Pessoa_Partido;
DROP TABLE IF EXISTS Projetos_Aprovados;
DROP TABLE IF EXISTS Projeto_Lei;

CREATE TABLE Altera_Decreto (
 id_decreto INTEGER,
 id_governo INTEGER,
 data DATE NOT NULL,
 FOREIGN KEY (id_decreto) REFERENCES Decreto_Lei (id_decreto) ON DELETE SET NULL ON UPDATE CASCADE,
 FOREIGN KEY (id_governo) REFERENCES Governo (id_governo) ON DELETE SET NULL ON UPDATE SET NULL
);

CREATE TABLE Decreto_Lei (
 id_decreto INTEGER PRIMARY KEY,
 codigo INTEGER(3) NOT NULL,
 data_aprovacao DATE,
 descricao text,
 id_projeto INTEGER(11) NOT NULL,
 FOREIGN KEY (id_projeto) REFERENCES Projeto_Lei (id_projeto) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE Espetro (
 id_espetro INTEGER PRIMARY KEY,
 nome VARCHAR(30) NOT NULL
);

CREATE TABLE Governo (
 id_governo INTEGER PRIMARY KEY,
 dataInicio DATE,
 dataFim DATE,
 maioria tinyINTEGER(1) DEFAULT 0,
 maximo_membros INTEGER DEFAULT 3
);

CREATE TABLE Grupo_Parlamentar (
 id_grupo INTEGER PRIMARY KEY,
 nome VARCHAR(30) NOT NULL
);

CREATE TABLE Mesa (
 id_mesa INTEGER PRIMARY KEY,
 descricao text NOT NULL,
 dataInicio DATE NOT NULL,
 dataFim DATE NOT NULL
);

CREATE TABLE Ministerio (
 id_ministerio INTEGER PRIMARY KEY,
 nome VARCHAR(50) NOT NULL,
 id_governo INTEGER NOT NULL,
 FOREIGN KEY (id_governo) REFERENCES Governo (id_governo) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE Parlamento (
 id_parlamento INTEGER PRIMARY KEY,
 localSede VARCHAR(30) NOT NULL,
 ultimaEleicao DATE,
 tipo VARCHAR(20) NOT NULL,
 id_governo INTEGER,
 FOREIGN KEY (id_governo) REFERENCES Governo (id_governo) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE Partido (
 id_partido INTEGER PRIMARY KEY,
 nome VARCHAR(30) NOT NULL,
 id_espetro INTEGER,
 FOREIGN KEY (id_espetro) REFERENCES Espetro (id_espetro) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE Pessoa (
 id_pessoa INTEGER PRIMARY KEY,
 nome VARCHAR(50) NOT NULL,
 dataNasc DATE NOT NULL
);

CREATE TABLE Pessoa_Grupo ( 
 id_pessoa INTEGER, 
 id_grupo INTEGER, 
 papel VARCHAR(50) NOT NULL, 
 dataInicio DATE NOT NULL, 
 PRIMARY KEY (id_pessoa, id_grupo),
 FOREIGN KEY (id_pessoa) REFERENCES Pessoa(id_pessoa) ON DELETE SET NULL ON UPDATE CASCADE,
 FOREIGN KEY (id_grupo) REFERENCES Grupo_Parlamentar(id_grupo) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE Pessoa_Mesa ( 
 id_pessoa INTEGER, 
 id_mesa INTEGER, 
 papel VARCHAR(50), 
 dataInicio DATE, 
 PRIMARY KEY (id_pessoa,id_mesa), 
 FOREIGN KEY (id_pessoa) REFERENCES Pessoa (id_pessoa) ON DELETE SET NULL ON UPDATE CASCADE, 
 FOREIGN KEY (id_mesa) REFERENCES Mesa (id_mesa) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE Pessoa_Ministerio ( 
 id_pessoa INTEGER, 
 id_ministerio INTEGER, 
 papel VARCHAR(50), 
 dataInicio DATE, 
 PRIMARY KEY (id_pessoa,id_ministerio), 
 FOREIGN KEY (id_pessoa) REFERENCES Pessoa (id_pessoa) ON DELETE SET NULL ON UPDATE CASCADE, 
 FOREIGN KEY (id_ministerio) REFERENCES Ministerio (id_ministerio) ON DELETE SET NULL ON UPDATE CASCADE 
);

CREATE TABLE Pessoa_Parlamento ( 
 id_pessoa INTEGER, 
 id_parlamento INTEGER, 
 papel VARCHAR(50), 
 dataInicio DATE, 
 PRIMARY KEY (id_pessoa, id_parlamento),  
 FOREIGN KEY (id_pessoa) REFERENCES Pessoa (id_pessoa) ON DELETE CASCADE ON UPDATE CASCADE, 
 FOREIGN KEY (id_parlamento) REFERENCES Parlamento (id_parlamento) ON DELETE SET NULL ON UPDATE CASCADE 
);

CREATE TABLE Pessoa_Partido ( 
 id_pessoa INTEGER, 
 id_partido INTEGER, 
 papel varchar(50), 
 dataInicio DATE, 
 PRIMARY KEY (id_pessoa,id_partido),
 FOREIGN KEY (id_pessoa) REFERENCES Pessoa(id_pessoa) ON DELETE CASCADE ON UPDATE CASCADE,
 FOREIGN KEY (id_partido) REFERENCES Partido(id_partido) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE Projetos_Aprovados ( 
 id_projeto INTEGER, 
 id_governo INTEGER DEFAULT NULL,
 id_grupo INTEGER DEFAULT NULL,
 PRIMARY KEY (id_projeto),
 FOREIGN KEY (id_projeto) REFERENCES Projeto_Lei (id_projeto) ON DELETE CASCADE ON UPDATE CASCADE,
 FOREIGN KEY (id_governo) REFERENCES Governo (id_governo) ON DELETE CASCADE ON UPDATE CASCADE,
 FOREIGN KEY (id_grupo) REFERENCES Grupo_Parlamentar (id_grupo) ON DELETE CASCADE ON UPDATE CASCADE 
);
 
CREATE TABLE Projeto_Lei (
 id_projeto INTEGER PRIMARY KEY,
 descricao text NOT NULL,
 codigo INTEGER NOT NULL
);