
/*1) Qual o(s) Governo(s) que aprovaram mais decretos?*/

SELECT id_governo 
FROM num_decretos_governo
WHERE contagem IN(
SELECT MAX(contagem) AS maximo
FROM num_decretos_governo);

/*2) Qual o(s) Governo(s) que alteraram mais decretos?*/

SELECT id_governo
FROM num_decretos_alterados
WHERE contagem IN (
SELECT MAX(contagem) AS maximo
FROM num_decretos_alterados);

/*3) Em quantos Governos esteve cada deputado? Mostre o nome dos deputados e os resultados ordenados por ordem decrescente de número de governos.*/

SELECT Pessoa.nome, COUNT(*) AS num_governos
FROM Pessoa
INNER JOIN Pessoa_Parlamento ON (Pessoa_Parlamento.id_pessoa = Pessoa.id_pessoa)
INNER JOIN Parlamento ON (Parlamento.id_parlamento = Pessoa_Parlamento.id_parlamento)
INNER JOIN Governo ON (Governo.id_governo = Parlamento.id_governo)
GROUP BY Pessoa.id_pessoa
ORDER BY num_governos DESC;

/*4) Quais as pessoas que pertencem ao Ministério da Educação?*/

SELECT Pessoa.nome
FROM Pessoa
INNER JOIN Pessoa_Ministerio ON (Pessoa.id_pessoa = Pessoa_Ministerio.id_pessoa)
INNER JOIN Ministerio ON (Ministerio.id_ministerio = Pessoa_Ministerio.id_ministerio)
WHERE Ministerio.nome = "Ministerio da Educacao";

/*5) Qual a percentagem de deputados de cada partido presentes na Assembleia?*/

SELECT partido, (COUNT(*)/(num*1.0))*100 AS percentagem FROM(
SELECT Pessoa.nome, Partido.nome AS partido FROM Pessoa
INNER JOIN Pessoa_Parlamento ON (Pessoa_Parlamento.id_pessoa = Pessoa.id_pessoa)
INNER JOIN Parlamento ON (Parlamento.id_parlamento = Pessoa_Parlamento.id_parlamento)
INNER JOIN Pessoa_Partido ON (Pessoa_Partido.id_pessoa = Pessoa.id_pessoa)
INNER JOIN Partido ON (Pessoa_Partido.id_partido = Partido.id_partido)
WHERE Parlamento.id_parlamento IN
(SELECT id_parlamento FROM Ultimo_Parlamento))Partidos_Num_Membros_Parlamento, Num_Pessoas_Parlamento
GROUP BY partido;

/*6) Qual o "sucesso" de cada Governo? Ordene os resultados de forma decrescente (o Governo que obteve mais sucesso é o que aprovou mais decretos).*/

SELECT Governo.id_governo, COUNT(Decreto_Lei.id_projeto) AS num_decretos
FROM Governo
LEFT JOIN Projetos_Aprovados ON (Projetos_Aprovados.id_governo = Governo.id_governo)
LEFT JOIN Decreto_Lei ON (Projetos_Aprovados.id_projeto = Decreto_Lei.id_projeto)
GROUP BY Governo.id_governo
ORDER BY num_decretos DESC;

/*7) Quantas alterações sofreu cada decreto?*/

SELECT id_decreto, COUNT(*) AS num_vezes
FROM altera_decreto
GROUP BY id_decreto;

/*8) Quais os decretos-lei que nunca foram alterados?*/

SELECT Decreto_Lei.id_decreto, COUNT(Altera_Decreto.id_decreto) AS num_alteracoes
FROM Decreto_Lei
LEFT JOIN Altera_Decreto ON (Decreto_Lei.id_decreto = Altera_Decreto.id_decreto)
LEFT JOIN Projeto_Lei ON (Projeto_Lei.id_projeto = Decreto_Lei.id_projeto)
GROUP BY Decreto_Lei.id_decreto
HAVING num_alteracoes = 0;

/*9) Quais as pessoas que nunca foram eleitas para um Governo?*/

SELECT Pessoa.nome
FROM Pessoa
LEFT JOIN Pessoa_Ministerio ON (Pessoa_Ministerio.id_pessoa = Pessoa.id_pessoa)
LEFT JOIN Ministerio ON (Ministerio.id_ministerio = Pessoa_Ministerio.id_ministerio)
LEFT JOIN Pessoa_Parlamento ON (Pessoa_Parlamento.id_pessoa = Pessoa.id_pessoa)
WHERE Ministerio.id_ministerio IS NULL
AND Pessoa_Parlamento.papel != "Primeiro-Ministro" AND Pessoa_Parlamento.papel != "Vice-Primeiro-Ministro";

/*10) Qual o(s) Ministério(s) que contêm mais membros em cada Governo?*/

SELECT Governo.id_governo, Ministerio.nome
FROM (SELECT id_governo, id_ministerio, MAX(num_membros) AS maximo_membros
FROM num_membros_ministerios
GROUP BY id_governo)Ministerios_Mais_Membros
INNER JOIN Governo ON (Governo.id_governo = Ministerios_Mais_Membros.id_governo)
INNER JOIN Ministerio ON (Ministerio.id_ministerio = Ministerios_Mais_Membros.id_ministerio);

/*11) Quais as pessoas que pertencem a um certo Governo? (por exemplo, o Governo com id_governo = 1)*/

SELECT Pessoa.nome
FROM Pessoa
INNER JOIN Pessoa_Parlamento ON (Pessoa.id_pessoa = Pessoa_Parlamento.id_pessoa)
INNER JOIN Parlamento ON (Parlamento.id_parlamento = Pessoa_Parlamento.id_parlamento)
INNER JOIN Governo ON (Parlamento.id_governo = Governo.id_governo)
WHERE Governo.id_governo = 1
AND Pessoa_Parlamento.papel NOT IN ("Deputado", "Presidente da Assembleia", "Vice-Presidente", "Presidente da Republica");